from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username, password):
        """
        Initialize the MongoClient and connect to the AAC database.
        
        Parameters:
            username (str): MongoDB username for authentication
            password (str): MongoDB password for authentication
        """
        self.client = MongoClient('localhost', 27017)
        self.database = self.client['aac']
        self.collection = self.database['animals']

    def create(self, data):
        """
        Insert a single document into the animals collection.
        
        Parameters:
            data (dict): Key/value pairs representing the document to insert
            
        Returns:
            bool: True if insert was successful, False otherwise
        """
        if data is None or not isinstance(data, dict):
            raise ValueError("Data parameter must be a non-empty dictionary.")
        
        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except Exception as e:
            print(f"Create error: {e}")
            return False

    def read(self, query):
        """
        Query for documents in the animals collection.
        
        Parameters:
            query (dict): Key/value pairs to filter results
            
        Returns:
            list: List of matching documents, or empty list if none found
        """
        if query is None or not isinstance(query, dict):
            raise ValueError("Query parameter must be a dictionary.")
        
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, update_data):
        """
        Update document(s) in the animals collection that match the query.
        
        Parameters:
            query (dict): Key/value pairs to identify document(s) to update
            update_data (dict): Key/value pairs with the new data to apply
            
        Returns:
            int: Number of documents modified
        """
        if query is None or not isinstance(query, dict):
            raise ValueError("Query parameter must be a dictionary.")
        if update_data is None or not isinstance(update_data, dict):
            raise ValueError("Update data parameter must be a dictionary.")
        
        try:
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        except Exception as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query):
        """
        Remove document(s) from the animals collection that match the query.
        
        Parameters:
            query (dict): Key/value pairs to identify document(s) to remove
            
        Returns:
            int: Number of documents deleted
        """
        if query is None or not isinstance(query, dict):
            raise ValueError("Query parameter must be a dictionary.")
        
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Delete error: {e}")
            return 0